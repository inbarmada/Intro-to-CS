############################################################
# FILE : ex3.py
# WRITER : Inbar Leibovich , inbarlei , 21395389
# EXERCISE : intro2cse Ex3 2020
# DESCRIPTION: 
# STUDENTS I DISCUSSED THE EXERCISE WITH: 
# WEB PAGES I USED: 
# NOTES:
############################################################


def input_list():
    nums = []
    list_sum = 0
    while True:
        x = input()
        print(x)
        if not x:
            break
        nums.append(float(x))
        list_sum += float(x)
    nums.append(list_sum)
    return nums


def inner_product(vec_1, vec_2):
    if len(vec_1) != len(vec_2):
        return None
    product = 0
    for i in range(len(vec_1)):
        product += vec_1[i] * vec_2[i]
    return product

def sequence_monotonicity(sequence):
    if len(sequence) == 1:
        return [True, True, True, True]
    increasing = True
    decreasing = True
    constant = False
    for i in range(1, len(sequence)):
        if sequence[i] > sequence[i - 1]:
            decreasing = False
        elif sequence[i] < sequence[i - 1]:
            increasing = False
        else:
            constant = True

    monotonicity = [False, False, False, False]
    monotonicity[0] = increasing
    monotonicity[1] = increasing and not constant
    monotonicity[2] = decreasing
    monotonicity[3] = decreasing and not constant
    return monotonicity


def monotonicity_inverse(def_bool):
    # [T, *, F, F]
    if def_bool[0] and (not def_bool[2] and not def_bool[3]):
        if def_bool[1]:
            return [1, 2, 3]
        else:
            return [1, 2, 3, 3]

    # [F, F, T, *]
    elif def_bool[2] and (not def_bool[0] and not def_bool[1]):
        if def_bool[3]:
            return [3, 2, 1]
        else:
            return [3, 3, 2, 1]

    # [T, F, T, F]
    elif def_bool == [True, False, True, False]:
        return [1, 1, 1]

    # [T, T, T, T]
    elif def_bool == [True, True, True, True]:
        return [1]

    # [F, F, F, F]
    elif def_bool == [False, False, False, False]:
        return [1, 2, 3, 2, 1]

    else:
        return None


# Can this be improved?
def primes_for_asafi(n):
    if n == 0:
        return []
    primes = [2]
    i = 3
    while len(primes) < n:
        j = 2
        while j**2 <= i:
            if i % j == 0:
                break
            j += 1
        else:
            primes.append(i)
        i += 2

    return primes


# Can we assume all vector lists are the same length?
def sum_of_vectors(vec_lst):
    if len(vec_lst) == 0:
        return None
    sum_list = [0] * len(vec_lst[0])

    for i in range(len(vec_lst)):
        for j in range(len(vec_lst[i])):
            sum_list[j] += vec_lst[i][j]

    return sum_list


def num_of_orthogonal(vectors):
    num_orthogonal = 0;
    for i in range(len(vectors)):
        for j in range(i+1, len(vectors)):
            if inner_product(vectors[i], vectors[j]) == 0:
                num_orthogonal += 1

    return num_orthogonal

# print(sequence_monotonicity([1, 1, 1, 1]))
