############################################################
# FILE : shapes.py
# WRITER : Inbar Leibovich , inbarlei , 21395389
# EXERCISE : intro2cse Ex2 2020
# DESCRIPTION: 
# STUDENTS I DISCUSSED THE EXERCISE WITH: 
# WEB PAGES I USED: 
# NOTES:
############################################################
import math


def shape_area():
    shape = int(input("Choose shape (1=circle, 2=rectangle, 3=triangle): "))
    if shape == 1:
        return circle_area()
    elif shape == 2:
        return rectangle_area()
    elif shape == 3:
        return triangle_area()


def circle_area():
    r = float(input())
    return r*r*math.pi


def rectangle_area():
    side_a = float(input())
    side_b = float(input())
    return side_a * side_b


def triangle_area():
    a = float(input())
    equilateral_triangle_constant = (3 ** 0.5) / 4
    return a * a * equilateral_triangle_constant
