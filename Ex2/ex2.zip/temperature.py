############################################################
# FILE : temperature.py
# WRITER : Inbar Leibovich , inbarlei , 21395389
# EXERCISE : intro2cse Ex2 2020
# DESCRIPTION: 
# STUDENTS I DISCUSSED THE EXERCISE WITH: 
# WEB PAGES I USED: 
# NOTES:
############################################################


def is_it_summer_yet(threshold_temp, day_one_temp, day_two_temp, day_three_temp):
    days_over_threshold = 0
    if day_one_temp > threshold_temp:
        days_over_threshold += 1
    if day_two_temp > threshold_temp:
        days_over_threshold += 1
    if day_three_temp > threshold_temp:
        days_over_threshold += 1

    if days_over_threshold >= 2:
        return True
    else:
        return False
