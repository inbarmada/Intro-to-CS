############################################################
# FILE : calculate_mathematical_expression.py
# WRITER : Inbar Leibovich , inbarlei , 21395389
# EXERCISE : intro2cse Ex2 2020
# DESCRIPTION: 
# STUDENTS I DISCUSSED THE EXERCISE WITH: 
# WEB PAGES I USED: 
# NOTES:
############################################################


def calculate_mathematical_expression(a, b, operator):
    if (operator == '+'):
        return a + b
    elif (operator == '-'):
        return a - b
    elif (operator == '*'):
        return a * b
    elif (operator == '/'):
        if (b != 0):
            return a / b

def calculate_from_string(calc):
    a, operator, b = calc.split()
    num_a = float(a)
    num_b = float(b)
    return calculate_mathematical_expression(num_a, num_b, operator)

