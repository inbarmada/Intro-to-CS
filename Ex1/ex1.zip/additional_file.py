######################################################################
# FILE : additional_file.py
# WRITER : Inbar Leibovich, inbarlei, 21395389
# EXERCISE : intro2cse ex1 2020
# DESCRIPTION : Additional file with secret function
# ADDITIONAL COMMENTS:
######################################################################
def secret_function():
    '''Secret function'''
    print('My username is inbarlei and I should make sure to check the submission response.')

if __name__ == "__main__":
    secret_function()