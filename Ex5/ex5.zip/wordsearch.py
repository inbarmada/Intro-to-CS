############################################################
# FILE : wordsearch.py
# WRITER : Inbar Leibovich , inbarlei , 21395389
# EXERCISE : intro2cse Ex5 2020
# DESCRIPTION: Word search solver
# STUDENTS I DISCUSSED THE EXERCISE WITH: 
# WEB PAGES I USED: 
# NOTES:
############################################################

import sys
import os.path
from collections import Counter


def check_input_files(args):
    """ Check validity of input arguments"""
    msg = None
    if len(args) != 5:
        msg = "Wrong number of arguments"
    elif not os.path.isfile(args[1]):
        msg = "Word list file does not exist"
    elif not os.path.isfile(args[2]):
        msg = "Matrix file does not exist"
    elif not check_dir(args[4]):
        msg = "Incorrect directions"
    return msg


def check_dir(dirs):
    # Add directions to set
    directions = set(dirs)

    # Check if directions are valid
    valid_dirs = ['u', 'd', 'l', 'r', 'w', 'x', 'y', 'z']
    for d in directions:
        if d not in valid_dirs:
            return False

    return True


def read_wordlist_file(filename):
    word_list = []

    # Read file
    with open(filename, 'r') as file:
        for line in file.read().splitlines():
            word_list.append(line)

    return word_list


def read_matrix_file(filename):
    matrix = []

    # Read file
    with open(filename, 'r') as file:
        # Read line
        for line in file.read().splitlines():
            row = line.split(',')
            matrix.append(row)

    return matrix


def find_word_matrix(word_list, matrix, directions):
    words_found = Counter()
    for d in set(directions):
        words_found += direction_words(word_list, matrix, d)
    # WRONG - MUST RETURN AS TUPLES!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

    results = []
    for word in sorted(words_found.keys()):
        tup = (word, words_found[word])
        results.append(tup)

    return results


def direction_words(word_list, matrix, d):
    words_found = Counter()
    # Iterate through cells of matrix
    for row in range(len(matrix)):
        for col in range(len(matrix[row])):
            words_found.update(check_cell(word_list, matrix, d, row, col, 0))
    return words_found


def check_cell(word_list, matrix, d, row, col, num):
    found = []
    next_cell = []
    for word in word_list:
        if word[num] == matrix[row][col]:
            if len(word) == num + 1:
                found.append(word)
            else:
                next_cell.append(word)

    if not next_cell:
        return found
    else:
        row = new_row(row, d, len(matrix))
        col = new_col(col, d, len(matrix[0]))
        if row is not None and col is not None:
            return found + check_cell(next_cell, matrix, d, row, col, num + 1)
        else:
            return found


def new_row(row, d, length):
    if d in ['u', 'w', 'x']:
        row -= 1
    elif d in ['d', 'y', 'z']:
        row += 1
    if row < 0 or row >= length:
        row = None
    return row


def new_col(col, d, length):
    if d in ['l', 'x', 'z']:
        col -= 1
    elif d in ['r', 'w', 'y']:
        col += 1
    if col < 0 or col >= length:
        col = None
    return col


def write_output_file(results, output_filename):
    with open(output_filename, 'w') as file:
        for tup in results:
            file.write(tup[0] + "," + str(tup[1]) + "\n")


def search_words(args):
    if check_input_files(args) is None:
        word_list = read_wordlist_file(sys.argv[1])
        matrix = read_matrix_file(sys.argv[2])
        results = find_word_matrix(word_list, matrix, sys.argv[4])
        write_output_file(results, sys.argv[3])


if __name__ == "__main__":
    search_words(sys.argv)
